import numpy as np
from scipy.interpolate import RectBivariateSpline

def LucasKanade(It, It1, rect):
    # Input:
    #   It: template image
    #   It1: current image
    #   rect: [x1, y1, x2, y2]
    # Output:
    #   p: [dx, dy] translation vector

    threshold = 0.01875
    maxIters = 100
    p = np.zeros(2)
    x1, y1, x2, y2 = rect

    # interpolation objects
    It_spline = RectBivariateSpline(np.arange(It.shape[0]), np.arange(It.shape[1]), It)
    It1_spline = RectBivariateSpline(np.arange(It1.shape[0]), np.arange(It1.shape[1]), It1)

    # Generate meshgrid of template coordinates
    x = np.arange(x1, x2 + 1)
    y = np.arange(y1, y2 + 1)
    X, Y = np.meshgrid(x, y)
    X_flat = X.ravel()
    Y_flat = Y.ravel()

    # Template values (fixed)
    T_vals = It_spline.ev(Y_flat, X_flat)

    for _ in range(maxIters):
        # Warp current frame using current p
        X_warp = X_flat + p[0]
        Y_warp = Y_flat + p[1]

        # bounds Check
        if np.any(X_warp < 0) or np.any(X_warp >= It1.shape[1] - 1) or \
           np.any(Y_warp < 0) or np.any(Y_warp >= It1.shape[0] - 1):
            break

        # Interpolated values from current frame
        I_vals = It1_spline.ev(Y_warp, X_warp)
        error = (T_vals - I_vals).reshape(-1, 1)

        # image gradients at warped locations
        Ix = It1_spline.ev(Y_warp, X_warp, dx=0, dy=1).reshape(-1, 1)
        Iy = It1_spline.ev(Y_warp, X_warp, dx=1, dy=0).reshape(-1, 1)

        # Jacobian for translation: constant [Ix Iy]
        J = np.hstack((Ix, Iy))

        # Solve least squares for dp
        dp, _, _, _ = np.linalg.lstsq(J, error, rcond=None)

        # Update parameters
        p += dp.flatten()

        # convergence Check
        if np.linalg.norm(dp) < threshold:
            break

    return p

