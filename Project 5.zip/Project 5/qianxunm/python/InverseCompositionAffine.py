import numpy as np
from scipy.interpolate import RectBivariateSpline

def InverseCompositionAffine(It, It1, rect):
    # Inputs:
    #   It: template image
    #   It1: current image
    #   rect: [x1, y1, x2, y2]
    # Output:
    #   M: 2x3 affine transformation matrix

    threshold = 0.01875
    maxIters = 100
    p = np.zeros(6)

    # Clamp bounding box to image boundaries
    x1, y1, x2, y2 = map(int, rect)
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(It.shape[1] - 1, x2), min(It.shape[0] - 1, y2)

    # Meshgrid for template patch
    X = np.arange(x1, x2)
    Y = np.arange(y1, y2)
    xx, yy = np.meshgrid(X, Y)
    coords = np.vstack([xx.ravel(), yy.ravel()])

    # Interpolators
    T_interp = RectBivariateSpline(np.arange(It.shape[0]), np.arange(It.shape[1]), It)
    I_interp = RectBivariateSpline(np.arange(It1.shape[0]), np.arange(It1.shape[1]), It1)

    # Template & gradients
    T_vals = T_interp.ev(coords[1], coords[0])
    dTx = T_interp.ev(coords[1], coords[0], dy=1)
    dTy = T_interp.ev(coords[1], coords[0], dx=1)

    # Jacobian matrix (constant)
    x, y = coords
    J = np.column_stack([
        x * dTx, y * dTx, dTx,
        x * dTy, y * dTy, dTy
    ])
    H_inv = np.linalg.pinv(J.T @ J)

    for _ in range(maxIters):
        # Warp coordinates
        x_warp = (1 + p[0]) * xx + p[1] * yy + p[2]
        y_warp = p[3] * xx + (1 + p[4]) * yy + p[5]
        x_warp, y_warp = x_warp.ravel(), y_warp.ravel()

        # Evaluate image and compute error
        I_vals = I_interp.ev(y_warp, x_warp)
        error = (I_vals - T_vals)[:, None]

        # update
        dp = H_inv @ (J.T @ error)
        dp = dp.ravel()

        # Compose warp matrices in-place
        P = np.eye(3)
        DP = np.eye(3)
        P[:2, :] += np.array([[p[0], p[1], p[2]], [p[3], p[4], p[5]]])
        DP[:2, :] += np.array([[dp[0], dp[1], dp[2]], [dp[3], dp[4], dp[5]]])
        p = (P @ np.linalg.inv(DP) - np.eye(3))[:2].ravel()

        if np.linalg.norm(dp) < threshold:
            break

    # reshape the output affine matrix
    M = np.array([[1.0+p[0], p[1],    p[2]],
                  [p[3],     1.0+p[4], p[5]]]).reshape(2, 3)

    return M

