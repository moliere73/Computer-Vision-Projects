
import numpy as np
from scipy.interpolate import RectBivariateSpline

def LucasKanadeAffine(It, It1, rect):
    # Inputs:
    #   It: template image
    #   It1: current image
    #   rect: [x1, y1, x2, y2]
    # Output:
    #   M: 2x3 affine transformation matrix

    threshold = 0.01875
    maxIters = 100
    p = np.zeros(6)
    x1, y1, x2, y2 = rect

    # Clamp rectangle -> image boundaries
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(It.shape[1] - 1, x2), min(It.shape[0] - 1, y2)

    # Generate meshgrid for template region
    X = np.arange(x1, x2 + 1)
    Y = np.arange(y1, y2 + 1)
    xx, yy = np.meshgrid(X, Y)
    x_flat = xx.ravel()
    y_flat = yy.ravel()

    # Interpolation splines for both frames
    T_spline = RectBivariateSpline(np.arange(It.shape[0]), np.arange(It.shape[1]), It)
    I_spline = RectBivariateSpline(np.arange(It1.shape[0]), np.arange(It1.shape[1]), It1)

    # Template pixel values (fixed)
    T_vals = T_spline.ev(y_flat, x_flat)

    for _ in range(maxIters):
        # Warp coordinates w. current affine parameters
        x_warp = (1 + p[0]) * xx + p[1] * yy + p[2]
        y_warp = p[3] * xx + (1 + p[4]) * yy + p[5]
        x_warp_flat = x_warp.ravel()
        y_warp_flat = y_warp.ravel()

        # bounds
        if np.any(x_warp_flat < 0) or np.any(x_warp_flat >= It1.shape[1] - 1) or \
           np.any(y_warp_flat < 0) or np.any(y_warp_flat >= It1.shape[0] - 1):
            break

        # Current image values & gradients at warped locations
        I_vals = I_spline.ev(y_warp_flat, x_warp_flat)
        Ix = I_spline.ev(y_warp_flat, x_warp_flat, dx=0, dy=1)
        Iy = I_spline.ev(y_warp_flat, x_warp_flat, dx=1, dy=0)

        # error image
        error = (T_vals - I_vals).reshape(-1, 1)

        # Construct the steepest descent matrix A
        A = np.vstack([
            x_flat * Ix, y_flat * Ix, Ix,
            x_flat * Iy, y_flat * Iy, Iy
        ]).T

        # Solve for parameter update
        dp, _, _, _ = np.linalg.lstsq(A, error, rcond=None)

        # Update parameters
        p += dp.ravel()

        # convergence Checker
        if np.linalg.norm(dp) < threshold:
            break

    # reshape output affine matrix
    M = np.array([[1.0+p[0], p[1],    p[2]],
                 [p[3],     1.0+p[4], p[5]]]).reshape(2, 3)
    return M


