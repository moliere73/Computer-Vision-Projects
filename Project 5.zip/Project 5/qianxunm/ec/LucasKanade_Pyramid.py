import numpy as np
import cv2
from scipy.interpolate import RectBivariateSpline
from LucasKanade import LucasKanade  # Use Q3.1 implementation

def build_pyramid(image, levels):
    """Constructs image pyramid using Gaussian downsampling."""
    pyramid = [image]
    for _ in range(1, levels):
        image = cv2.pyrDown(image)
        pyramid.append(image)
    return pyramid[::-1]  # return from coarse to fine

def LucasKanadePyramid(It, It1, rect, threshold=0.01875, num_iters=100, levels=3):
    """
    Lucas-Kanade tracker using image pyramid.

    Inputs:
        It: template image
        It1: current image
        rect: [x1, y1, x2, y2] on full-size image
        threshold: convergence threshold
        num_iters: maximum iterations per level
        levels: number of pyramid levels

    Returns:
        p: [dx, dy] displacement from It to It1
    """
    # Build pyramids (from coarse to fine)
    pyr_It = build_pyramid(It, levels)
    pyr_It1 = build_pyramid(It1, levels)

    # Scale rectangle for top pyramid level
    scale = 1 / (2 ** (levels - 1))
    rect_scaled = [r * scale for r in rect]
    p = np.zeros(2)

    for level in range(levels):
        # Current pyramid scale
        s = 2 ** (level - (levels - 1))
        It_lvl = pyr_It[level]
        It1_lvl = pyr_It1[level]

        # Scale rect to current level
        rect_lvl = [r * s for r in rect]

        # Shift rect with current p estimate
        rect_shifted = [rect_lvl[0] + p[0], rect_lvl[1] + p[1],
                        rect_lvl[2] + p[0], rect_lvl[3] + p[1]]

        # Estimate delta p at this level
        dp = LucasKanade(It_lvl, It1_lvl, rect_shifted)
        p += dp * s  # scale update to current level resolution

    return p
