import numpy as np
import cv2
from planarH import computeH_ransac
from matchPics import matchPics

def blend_images(image1, image2):
    """Blends two overlapping images using a linear gradient for smooth transition."""
    overlap_mask = (image2 > 0).astype(np.float32)
    blend_alpha = np.linspace(0, 1, overlap_mask.shape[1])  # Linear blending across width
    blend_alpha = np.tile(blend_alpha, (overlap_mask.shape[0], 1))[:, :, None]
    return (image1 * (1 - blend_alpha) + image2 * blend_alpha).astype(np.uint8)

# Load images
left_image = cv2.imread('../ec/left.jpg')
right_image = cv2.imread('../ec/right.jpg')

if left_image is None or right_image is None:
    raise ValueError("Error loading images. Check file paths.")

# Get image dimensions
left_height, left_width = left_image.shape[:2]
right_height, right_width = right_image.shape[:2]

# Feature Matching
matched_features, keypoints_left, keypoints_right = matchPics(left_image, right_image)
if len(matched_features) < 4:
    raise ValueError("Not enough feature matches found.")

# Extract matched points
matched_points_left = keypoints_left[matched_features[:, 0]]
matched_points_right = keypoints_right[matched_features[:, 1]]

# Swap (x, y) to (row, col) format
matched_points_left[:, [1, 0]] = matched_points_left[:, [0, 1]]
matched_points_right[:, [1, 0]] = matched_points_right[:, [0, 1]]

# Compute Homography using RANSAC
homography_right_to_left, inliers = computeH_ransac(matched_points_left, matched_points_right)

# Warp images
right_corners = np.array([
    [0, 0, right_width - 1, right_width - 1],  # x-coordinates
    [0, right_height - 1, right_height - 1, 0],  # y-coordinates
    [1, 1, 1, 1]  # Homogeneous coordinates
])

# Transform right image corners to left image's coordinate space
warped_right_corners = homography_right_to_left @ right_corners
warped_right_corners /= warped_right_corners[-1, :]
warped_right_corners = warped_right_corners.round().astype(int)

# Compute dimensions for final panorama
final_height_max = max(left_height, np.amax(warped_right_corners[1, :]))
final_width_max = max(left_width, np.amax(warped_right_corners[0, :]))
final_height_min = min(0, np.amin(warped_right_corners[1, :]))
final_width_min = min(0, np.amin(warped_right_corners[0, :]))

final_height = final_height_max - final_height_min
final_width = final_width_max - final_width_min

# Translation matrix to shift images correctly
translation_matrix = np.array([
    [1.0, 0.0, -final_width_min],
    [0.0, 1.0, -final_height_min],
    [0.0, 0.0, 1.0]
])

# Warp both images to final panorama space
warped_left_image = cv2.warpPerspective(left_image, translation_matrix, (final_width, final_height))
warped_right_image = cv2.warpPerspective(right_image, translation_matrix @ homography_right_to_left, (final_width, final_height))

# Blend images smoothly
panorama_result = blend_images(warped_left_image, warped_right_image)

# Save and display
cv2.imwrite('../result/panorama.jpg', panorama_result)
cv2.imshow("Panorama", panorama_result)
cv2.waitKey(0)
cv2.destroyAllWindows()
