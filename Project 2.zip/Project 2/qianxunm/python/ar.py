import numpy as np
import cv2
import os
from loadVid import loadVid
from planarH import computeH_ransac, compositeH
from matchPics import matchPics

def create_ar_video():
    # Load videos & reference images
    print("Loading videos and reference images...")
    cv_cover = cv2.imread('../data/cv_cover.jpg')
    ar_frames = loadVid('../data/ar_source.mov')
    book_frames = loadVid('../data/book.mov')
    
    # Get video properties
    num_frames = min(len(ar_frames), len(book_frames))
    h, w, _ = cv_cover.shape
    output_h, output_w, _ = book_frames[0].shape
    
    # Pre-process AR content once
    print("Pre-processing AR content...")
    ar_frames_processed = []
    for frame in ar_frames[:num_frames]:
        h1, w1, _ = frame.shape
        # Calculate crop region
        left = int(max(w1/2-w/2, 0))
        right = int(min(w1/2+(w/2), w1))
        # Adding offset
        top = int(max(h1/2-(h/2), 0) + 70) 
        # Subtracting offset 
        bottom = int(min(h1/2+h/2, h1) - 70)  
        
        # Crop & resize
        cropped = frame[top:bottom, left:right]
        resized = cv2.resize(cropped, (w, h))
        ar_frames_processed.append(resized)
    
    # Create output directory if it doesn't exist
    output_dir = '../result'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Set up video writer
    print("Setting up video writer...")
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(f'{output_dir}/ar_output.avi', fourcc, 25, (output_w, output_h))
    
    # Create a simple progress bar
    # Update every 5%
    progress_step = max(1, num_frames // 20)  
    
    # Process each frame
    print(f"Processing {num_frames} frames...")
    for i in range(num_frames):
        # Progress reporting
        if i % progress_step == 0:
            print(f"Processing frame {i}/{num_frames} ({i/num_frames*100:.1f}%)")
        
        book_frame = book_frames[i]
        ar_frame = ar_frames_processed[i]
        
        # Find matches
        matches, locs1, locs2 = matchPics(cv_cover, book_frame)
        
        # If enough matches, compute homography
        # Requiring at least 5 matches for stability
        if len(matches) > 4:  
            # Extract matched points
            locs1_matched = locs1[matches[:, 0]]
            locs2_matched = locs2[matches[:, 1]]
            
            try:
                # homography w. RANSAC
                bestH2to1, _ = computeH_ransac(locs2_matched, locs1_matched)
                
                # composite image
                output = compositeH(np.linalg.inv(bestH2to1), ar_frame, book_frame)
                out.write(output)
                
                # Optionally display the frame
                # cv2.imshow('AR Output', output)
                # if cv2.waitKey(1) & 0xFF == ord('q'):
                #     break
                
            except Exception as e:
                print(f"Error in frame {i}: {e}")
                # Use original frame if error occurs
                out.write(book_frame)  
        else:
            # Not enough matches, use original frame
            out.write(book_frame)
        
    # Clean up
    print("Finalizing video...")
    out.release()
    cv2.destroyAllWindows()
    print(f"Processing complete! Video saved to {output_dir}/ar.avi")

if __name__ == "__main__":
    create_ar_video()