import os
import numpy as np
import cv2
from matchPics import matchPics
from helper import plotMatches
import skimage.color
import scipy.ndimage
import matplotlib.pyplot as plt

# Ensure output directory exists
output_dir = '../output'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

#Q3.5
#Read image & convert to grayscale, if necessary
cv_cover = cv2.imread('../data/cv_cover.jpg')

# image loads checker
if cv_cover is None:
    raise FileNotFoundError("Error: Could not read '../data/cv_cover.jpg'. Check file path.")

# Convert to grayscale if necessary
img = skimage.color.rgb2gray(cv_cover)

# Store #(matches) for each rotation
num_matches = np.zeros(36)

# Loop over rotation angles 
# (increments of 10°)
for i in range(36):
	# Compute rotation angle
	angle = i * 10 

	#Rotate Image
	#(maintain same dimensions with reshape=False)
	img_rot = scipy.ndimage.rotate(img, angle, reshape=False)
	
	#Compute features, descriptors and Match features
	matches, locs1, locs2 = matchPics(img, img_rot)

	# Store #(matches)
	num_matches[i] = matches.shape[0]
	print(f'Rotation degree: {angle}, Matches: {num_matches[i]}')

	# Plot matches for select angles (10°, 90°, 200°)
	if i in [1, 9, 20]:  
		cv_cover_rot = scipy.ndimage.rotate(cv_cover, angle, reshape=False)
		plt.figure(figsize=(10, 5))
		plotMatches(cv_cover, cv_cover_rot, matches, locs1, locs2)
		plt.title(f"Feature Matching at {angle}° Rotation")
		
		# Save figure safely
		save_path = os.path.join(output_dir, f'matches_{angle}.jpg')
		plt.savefig(save_path)
		plt.show()

	#Update histogram
# Display histogram of matches vs. rotation angle
plt.figure(figsize=(10, 5))
plt.bar(np.arange(0, 360, 10), num_matches, width=8, color='blue', alpha=0.7)
plt.xlabel("Rotation Degree")
plt.ylabel("Number of Matches")
plt.title("BRIEF Feature Matching vs. Rotation")
# spacing for x-axis ticks
plt.xticks(np.arange(0, 360, 30)) 

#Display histogram
plt.savefig(os.path.join(output_dir, 'q3_5.jpg'))
plt.show()

