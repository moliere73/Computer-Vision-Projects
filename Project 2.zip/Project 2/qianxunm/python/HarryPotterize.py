import numpy as np
import cv2
from matchPics import matchPics
from planarH import computeH_ransac, compositeH

def HarryPotterize():
    """
    Replaces the book cover in 'cv_desk.png' with 'hp_cover.jpg' using homography.
    """
    # Load images
    cv_cover = cv2.imread('../data/cv_cover.jpg')
    cv_desk = cv2.imread('../data/cv_desk.png')
    hp_cover = cv2.imread('../data/hp_cover.jpg')

    # images load correctly
    if cv_cover is None or cv_desk is None or hp_cover is None:
        print("Error: One or more image files could not be loaded. Check paths!")
        return None
    
    # Resize Harry Potter cover to match CV cover dimensions
    h_cover, w_cover = cv_cover.shape[:2]
    hp_cover_resized = cv2.resize(hp_cover, (w_cover, h_cover))

    # Find feature matches between cv_cover & cv_desk
    matches, locs1, locs2 = matchPics(cv_cover, cv_desk)

    # Extract matched points efficiently using numpy
	# Corresponding points in cv_cover
    locs1_matched = locs1[matches[:, 0], :2]  
	# Corresponding points in cv_desk
    locs2_matched = locs2[matches[:, 1], :2]  

    # homography w. RANSAC
    bestH2to1, _ = computeH_ransac(locs2_matched, locs1_matched)

    # Warp & blend the images
    output = compositeH(np.linalg.inv(bestH2to1), hp_cover_resized, cv_desk)

    # Display the result
    cv2.imshow("HarryPotterized", output)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    return output

if __name__ == "__main__":
    result = HarryPotterize()
    if result is not None:
        cv2.imwrite("../output/harrypotterized.jpg", result)
