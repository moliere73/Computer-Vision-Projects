import numpy as np
import cv2
import skimage.color
from helper import briefMatch
from helper import computeBrief
from helper import corner_detection

def matchPics(I1, I2):
	#I1, I2 : Images to match

	# Convert images to grayscale
    I1_gray = skimage.color.rgb2gray(I1) if I1.ndim == 3 else I1
    I2_gray = skimage.color.rgb2gray(I2) if I2.ndim == 3 else I2

    # Detect feature points using corner detection
    sigma = 0.15  # Adjust sigma for better feature detection
    locs1 = corner_detection(I1_gray, sigma)
    locs2 = corner_detection(I2_gray, sigma)

    # Compute BRIEF descriptors for detected features
    desc1, locs1 = computeBrief(I1_gray, locs1)
    desc2, locs2 = computeBrief(I2_gray, locs2)

    # Match BRIEF descriptors using briefMatch
    matches = briefMatch(desc1, desc2)

    return matches, locs1, locs2

