import numpy as np
import cv2

from scipy import linalg
#import scipy

def computeH(x1, x2):
	"""
	OUTPUT:
	H2to1 - a 3 x 3 matrix encoding the homography that best matches the linear 
	equation666 
	"""
	#Q3.6
	#Compute the homography between two sets of points

	# Check: at least 4 point matches
	if x1.shape[0] < 4 or x2.shape[0] < 4:
		raise ValueError("At least 4 point matches are required")

	# #(points)
	N = x1.shape[0]

	# Create A matrix for homogeneous linear system Ah = 0
	# For each point correspondence, have 2 rows in A
	A = np.zeros((2*N, 9))

	for i in range(N):
		# coordinates for this point pair
		x_1, y_1 = x1[i, 0], x1[i, 1]
		x_2, y_2 = x2[i, 0], x2[i, 1]
		
		# Fill in the rows of the A matrix
		# First row
		A[2*i, 0] = -x_2
		A[2*i, 1] = -y_2
		A[2*i, 2] = -1
		A[2*i, 3] = 0
		A[2*i, 4] = 0
		A[2*i, 5] = 0
		A[2*i, 6] = x_2 * x_1
		A[2*i, 7] = y_2 * x_1
		A[2*i, 8] = x_1
		
		# Second row
		A[2*i+1, 0] = 0
		A[2*i+1, 1] = 0
		A[2*i+1, 2] = 0
		A[2*i+1, 3] = -x_2
		A[2*i+1, 4] = -y_2
		A[2*i+1, 5] = -1
		A[2*i+1, 6] = x_2 * y_1
		A[2*i+1, 7] = y_2 * y_1
		A[2*i+1, 8] = y_1

	# VD of A
	U, S, Vt = np.linalg.svd(A)

	# solution: ast column of V (or last row of Vt)
	h = Vt[-1, :]

	# Reshape solution into a 3*3 matrix
	H2to1 = h.reshape(3, 3)

	# Normalize homography so that H[2,2] = 1
	H2to1 = H2to1 / H2to1[2, 2]

	return H2to1

def computeH_norm(x1, x2):
	assert x1.shape == x2.shape, "Error: x1 and x2 must have the same shape"
	N = x1.shape[0]
	assert N >= 4, "Error: At least 4 point correspondences are required."

	#Q3.7
	#Compute the centroid of the points
	centroid_x1 = np.mean(x1, axis=0)
	centroid_x2 = np.mean(x2, axis=0)

	#Shift the origin of the points to the centroid
	x1_shifted = x1 - centroid_x1
	x2_shifted = x2 - centroid_x2

	#Normalize the points so that the largest distance from the origin is equal to sqrt(2)
	avg_dist_x1 = np.mean(np.linalg.norm(x1_shifted, axis=1))
	avg_dist_x2 = np.mean(np.linalg.norm(x2_shifted, axis=1))

	scale_x1 = np.sqrt(2) / avg_dist_x1
	scale_x2 = np.sqrt(2) / avg_dist_x2

	x1_normalized = x1_shifted * scale_x1
	x2_normalized = x2_shifted * scale_x2

	#Similarity transform 1
	T1 = np.array([
        [scale_x1, 0, -scale_x1 * centroid_x1[0]],
        [0, scale_x1, -scale_x1 * centroid_x1[1]],
        [0, 0, 1]
    ])

	#Similarity transform 2
	T2 = np.array([
        [scale_x2, 0, -scale_x2 * centroid_x2[0]],
        [0, scale_x2, -scale_x2 * centroid_x2[1]],
        [0, 0, 1]
    ])

	#Compute homography
	H_normalized = computeH(x1_normalized, x2_normalized)

	#Denormalization
	H2to1 = np.linalg.inv(T1) @ H_normalized @ T2
	
	return H2to1

def computeH_ransac(x1, x2, num_iter=1000, threshold=5):
	"""
	OUTPUTS
	bestH2to1 - homography matrix with the most inliers found during RANSAC
	inliers - a vector of length N (len(matches)) with 1 at the those matches
		that are part of the consensus set, and 0 elsewhere.
	"""
	#Q3.8
	#Compute the best fitting homography given a list of matching points

	# Initialize variables
	N = x1.shape[0]
	assert N == x2.shape[0], "Point sets must have the same number of points"
	assert N >= 4, "At least 4 point correspondences are required"
	
	best_num_inliers = 0
	best_inliers = np.zeros(N, dtype=bool)
	best_H = None
	
	# Convert to homogeneous coordinates for projection later
	x1_homogeneous = np.hstack((x1, np.ones((N, 1))))
	x2_homogeneous = np.hstack((x2, np.ones((N, 1))))
	
	# RANSAC loop
	for i in range(num_iter):
		# 1. Randomly select 4 point correspondences
		random_indices = np.random.choice(N, 4, replace=False)
		x1_sample = x1[random_indices]
		x2_sample = x2[random_indices]
		
		# 2. Compute homography using the selected points
		try:
			H = computeH_norm(x1_sample, x2_sample)
		except np.linalg.LinAlgError:
			# Skip this iteration if the computation fails
			continue
		
		# 3. Compute inliers: project x2 to x1 space and check distances
		projected_x1 = np.zeros((N, 2))
		
		# Apply homography x1 = H*x2
		projected_homogeneous = np.dot(H, x2_homogeneous.T).T
		
		# Convert back from homogeneous coordinates
		projected_homogeneous[:, 0] /= projected_homogeneous[:, 2]
		projected_homogeneous[:, 1] /= projected_homogeneous[:, 2]
		projected_x1 = projected_homogeneous[:, :2]
		
		# Calculate Euclidean distance for each point
		distances = np.sqrt(np.sum((x1 - projected_x1)**2, axis=1))
		
		# Identify inliers
		current_inliers = distances < threshold
		num_inliers = np.sum(current_inliers)
		
		# 4. Update best model if we found more inliers
		if num_inliers > best_num_inliers:
			best_num_inliers = num_inliers
			best_inliers = current_inliers
			best_H = H
	
	# 5. Re-compute homography using all inliers from the best model
	if best_num_inliers > 4:
		try:
			best_H = computeH_norm(x1[best_inliers], x2[best_inliers])
		except np.linalg.LinAlgError:
			pass  # Keep the original best_H if recomputation fails
	
	# Convert boolean array to array of 0s and 1s
	inliers = best_inliers.astype(int)
	
	return best_H, inliers


def compositeH(H2to1, template, img):
    # image is uint8
    img = img.astype(np.uint8)
    
    # Transpose template 
	# (swap x and y axes)
    temp = np.transpose(template, (1, 0, 2))
    
    # Invert homography for warping template to image
    H = np.linalg.inv(H2to1)
    
    # Get dimensions
    w, h, channels1 = temp.shape
    w1, h1, channels2 = img.shape
    
    # Create mask of ones
    mask = np.ones((w, h, channels1), dtype=np.uint8)
    
    # Warp template & mask in one step
    warped_temp = cv2.warpPerspective(temp, H, (w1, h1))
    warped_mask = cv2.warpPerspective(mask, H, (w1, h1))
    
    # Transpose back
    warped_temp = np.transpose(warped_temp, (1, 0, 2))
    warped_mask = np.transpose(warped_mask, (1, 0, 2))
    
    # Create an inverted mask (where 0s will be where template goes)
    inv_mask = (warped_mask == 0).astype(np.uint8)
    
    # Apply mask to original image and add warped template
    masked_image = inv_mask * img
    composite_img = masked_image + warped_temp
    
    return composite_img
