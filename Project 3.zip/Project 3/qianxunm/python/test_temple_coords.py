import numpy as np
import skimage.io as io
import matplotlib.pyplot as plt

import submission as sub
import helper

import cv2

# 1. Load the two temple images and the points from data/some_corresp.npz
im1 = io.imread("../data/im1.png")
im2 = io.imread("../data/im2.png")

with np.load("../data/some_corresp.npz") as data:
    pts1 = data['pts1']
    pts2 = data['pts2']

# 2. Run eight_point to compute F
#TODO implement

# 2. Fundamental Matrix w. Eight-Point 
# normalization scale
M = max(im1.shape[0], im1.shape[1])  
# Call function
F = sub.eight_point(pts1, pts2, M)  

#F = None
print("Fundamental matrix\n", F, end="\n\n")
# for visualization
#helper.displayEpipolarF(im1, im2, F)

# 3. Load points in image 1 from data/temple_coords.npz
with np.load("../data/temple_coords.npz") as data:
    pts1 = data['pts1']

# 4. Run epipolar_correspondences to get points in image 2
#TODO implement
#pts2 = None

pts2 = sub.epipolar_correspondences(im1, im2, F, pts1)
# visualization
#helper.epipolarMatchGUI(im1, im2, F)

# 5. Load intrinsics data from data/intrinsics.npz
with np.load("../data/intrinsics.npz") as data:
    K1 = data["K1"]
    K2 = data["K2"]

# 6. Compute the essential matrix
#TODO implement
#E = None
E = sub.essential_matrix(F, K1, K2)
print("Essential Matrix\n", E, "\n")
###################################

'''
# 7. Create the camera projection matrix P1
# Assume that extrinsics = (I | 0)
#TODO implement
P1 = None

# 8. Use camera2 to get 4 camera projection matrices M2
#TODO implement
M2s = None

# 9. Run triangulate using the projection matrices and find out correct M2, P2, and pts_3d
#TODO implement
pts_3d = None
M2 = None
P2 = None

# 10. Get reprojection error
#TODO implement
reprojectionError = None
print("\nReprojection error: ", reprojectionError)
'''

# Load intrinsic camera parameters
data = np.load("../data/intrinsics.npz")
K1, K2 = data['K1'], data['K2']

# 7. Compute Camera Projection Matrix P1
P1 = K1 @ np.hstack((np.eye(3), np.zeros((3, 1))))  # Ensures [I | 0] for the first camera

# 8. Compute Essential Matrix & Get 4 Possible Extrinsic Matrices M2
E = sub.essential_matrix(F, K1, K2)
M2_candidates = helper.camera2(E)  # Returns (3,4,4) matrix

# Compute the 4 possible P2 matrices
P2s = [K2 @ M2_candidates[:, :, i] for i in range(4)]

# 9. Triangulate Using Each P2 & Select the Best One
results = [
    sub.triangulate(P1, pts1, P2, pts2) + (M2_candidates[:, :, i], P2)  # Store M2 explicitly
    for i, P2 in enumerate(P2s)
]

# Extract Results
pts_3ds, reprojection_errors, M2s, P2s = zip(*results)
num_positive_zs = [np.sum(pts_3d[:, 2] > 0) for pts_3d in pts_3ds]  # Count valid depths

# 10. Select the Best M2 (Most Positive-Depth Points)
best_idx = np.argmax(num_positive_zs)
M2, P2, pts_3d, best_reprojection_error = M2s[best_idx], P2s[best_idx], pts_3ds[best_idx], reprojection_errors[best_idx]

# Print results
print("\nReprojection Errors:", reprojection_errors)
print(f"\nBest P2 Index: {best_idx}, Final Reprojection Error: {best_reprojection_error:.4f} pixels")
print("\nBest M2 (Extrinsic Matrix):\n", M2)


# 11. Scatter plot the correct 3D points
# From https://pythonprogramming.net/matplotlib-3d-scatterplot-tutorial/
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

xData = pts_3d[:, 0]
yData = pts_3d[:, 1]
zData = pts_3d[:, 2]

ax.scatter(xData, yData, zData, c='b', marker='.')

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

plt.tight_layout(pad=0.1)
plt.show()

# 12. Save the computed extrinsic parameters (R1,R2,t1,t2) to results/extrinsics.npz
R1 = np.eye(3)
t1 = np.zeros((3,1))
R2 = M2[:, :3]
t2 = M2[:, 3:]
np.savez('../results/extrinsics.npz', R1=R1, t1=t1, R2=R2, t2=t2)

