"""
Homework 5
Submission Functions
"""

# import packages here
import numpy as np
import scipy

import helper

from scipy import linalg
import scipy.linalg

import skimage.color
from scipy.linalg import rq, svd

"""
Q3.1.1 Eight Point Algorithm
       [I] pts1, points in image 1 (Nx2 matrix)
           pts2, points in image 2 (Nx2 matrix)
           M, scalar value computed as max(H1,W1)
       [O] F, the fundamental matrix (3x3 matrix)
"""

def eight_point(pts1, pts2, M):
    # replace pass by your implementation
    #pass
    
    # 1. Normalize points:
    # using a transformation matrix T
    T = np.array([[1/M, 0, 0], 
                  [0, 1/M, 0], 
                  [0,  0, 1]])
    
    # points -> homogeneous coordinates
    pts1_h = np.column_stack((pts1, np.ones(pts1.shape[0])))
    pts2_h = np.column_stack((pts2, np.ones(pts2.shape[0])))
    
    # normalization
    # Transform points1
    pts1_norm = (T @ pts1_h.T).T  
    # Transform points2
    pts2_norm = (T @ pts2_h.T).T  

    # matrix A using correspondences
    A = np.zeros((pts1.shape[0], 9))
    for i in range(pts1.shape[0]):
        x1, y1 = pts1_norm[i, :2]
        x2, y2 = pts2_norm[i, :2]
        A[i] = [x1*x2, x1*y2, x1, y1*x2, y1*y2, y1, x2, y2, 1]

    # F w. SVD
    U, S, Vt = np.linalg.svd(A)
    # extract last column & reshape into 3x3 matrix
    F = Vt[-1].reshape(3, 3) 

    # Enforce rank-2 constraint w. SVD
    U, S, Vt = np.linalg.svd(F)
    # Set smallest singular value = 0 
    S[-1] = 0 
    # Reconstruct F w. rank 2
    F_rank2 = U @ np.diag(S) @ Vt  

    # Refine F w. helper 
    F_refined = helper.refineF(F_rank2, pts1_norm[:, :2], pts2_norm[:, :2])

    # Un-normalize F
    F_final = T.T @ F_refined @ T

    return F_final


"""
Q3.1.2 Epipolar Correspondences
       [I] im1, image 1 (H1xW1 matrix)
           im2, image 2 (H2xW2 matrix)
           F, fundamental matrix from image 1 to image 2 (3x3 matrix)
           pts1, points in image 1 (Nx2 matrix)
       [O] pts2, points in image 2 (Nx2 matrix)
"""
def epipolar_correspondences(im1, im2, F, pts1, window_size=5, search_range=50):
    #added parameters for image output

    # replace pass by your implementation
    #pass
    
    # Convert images -> grayscale if needed
    if im1.ndim == 3:
        im1 = skimage.color.rgb2gray(im1)
    if im2.ndim == 3:
        im2 = skimage.color.rgb2gray(im2)

    h2, w2 = im2.shape
    half_w = window_size // 2

    # Pad images -> handle edge cases
    im1_padded = np.pad(im1, ((half_w, half_w), (half_w, half_w)), mode='constant')
    im2_padded = np.pad(im2, ((half_w, half_w), (half_w, half_w)), mode='constant')

    pts2 = np.zeros_like(pts1)

    for i, (x, y) in enumerate(pts1.astype(int)):
        # epipolar line equation l' = F * [x, y, 1]
        a, b, c = (F @ np.array([x, y, 1])).flatten()

        # Search within a region along epipolar line 
        # for accuracy of correspondance
        min_x, max_x = max(0, x - search_range), min(w2, x + search_range)
        xs = np.arange(min_x, max_x)
        ys = np.clip((-a * xs - c) / b, 0, h2 - 1).astype(int) if b != 0 else np.full(xs.shape, y)

        # Extract patch from image 1
        patch1 = im1_padded[y:y + window_size, x:x + window_size]

        # SSD for all candidate points along epipolar line
        ssd = []
        for x2, y2 in zip(xs, ys):
            if 0 <= y2 < h2 - window_size and 0 <= x2 < w2 - window_size:
                patch2 = im2_padded[y2:y2 + window_size, x2:x2 + window_size]
                ssd.append(np.sum((patch1 - patch2) ** 2))
            else:
                # Ignore invalid areas
                ssd.append(np.inf)  

        # Select best match with minimum SSD
        best_idx = np.argmin(ssd)
        pts2[i] = [xs[best_idx], ys[best_idx]]

    return pts2

"""
Q3.1.3 Essential Matrix
       [I] F, the fundamental matrix (3x3 matrix)
           K1, camera matrix 1 (3x3 matrix)
           K2, camera matrix 2 (3x3 matrix)
       [O] E, the essential matrix (3x3 matrix)
"""
def essential_matrix(F, K1, K2):
    # replace pass by your implementation
    #pass
    # E: E = K2^T * F * K1
    E = K2.T @ F @ K1  

    # Enforce rank-2 constraint 
    # (last singular value is zero)
    '''
    U, S, Vt = np.linalg.svd(E)
    S[-1] = 0  
    E = U @ np.diag(S) @ Vt
    '''
    return E

"""
Q3.1.4 Triangulation
       [I] P1, camera projection matrix 1 (3x4 matrix)
           pts1, points in image 1 (Nx2 matrix)
           P2, camera projection matrix 2 (3x4 matrix)
           pts2, points in image 2 (Nx2 matrix)
       [O] pts3d, 3D points in space (Nx3 matrix)
"""
def triangulate(P1, pts1, P2, pts2):
    # replace pass by your implementation
    #pass
    # #(points)
    N = pts1.shape[0]  
    # Store homogeneous 3D points
    pts_3d = np.zeros((N, 4))  

    for i in range(N):
        x1, y1 = pts1[i]
        x2, y2 = pts2[i]

        # Construct the linear system A @ X = 0
        A = np.array([
            y1 * P1[2] - P1[1],  # Row 1
            P1[0] - x1 * P1[2],  # Row 2
            y2 * P2[2] - P2[1],  # Row 3
            P2[0] - x2 * P2[2],  # Row 4
        ])

        # Solve w. SVD
        _, _, Vt = np.linalg.svd(A)
        # Last row of V (smallest singular value)
        X_homogeneous = Vt[-1]  

        # Normalize -> Euclidean coordinates 
        # (avoid division by small values)
        pts_3d[i] = X_homogeneous / (X_homogeneous[-1] if abs(X_homogeneous[-1]) > 1e-6 else 1)

    # Extract only (X, Y, Z) coordinates
    pts_3d = pts_3d[:, :3]  

    # helper: reprojection error
    def compute_reprojection_error(P, pts2d, pts3d):
        N = pts3d.shape[0]
        # -> homogeneous coordinates
        pts3d_h = np.hstack((pts3d, np.ones((N, 1))))  
        # projection matrix
        projected_pts_h = (P @ pts3d_h.T).T  
        # Normalize -> 2D
        projected_pts = projected_pts_h[:, :2] / projected_pts_h[:, 2:]  

        # mean error
        return np.mean(np.linalg.norm(projected_pts - pts2d, axis=1))  

    # preprojection error for both images
    error1 = compute_reprojection_error(P1, pts1, pts_3d)
    error2 = compute_reprojection_error(P2, pts2, pts_3d)
    reprojection_error = (error1 + error2) / 2  

    return pts_3d, reprojection_error  


"""
Q3.2.1 Image Rectification
       [I] K1 K2, camera matrices (3x3 matrix)
           R1 R2, rotation matrices (3x3 matrix)
           t1 t2, translation vectors (3x1 matrix)
       [O] M1 M2, rectification matrices (3x3 matrix)
           K1p K2p, rectified camera matrices (3x3 matrix)
           R1p R2p, rectified rotation matrices (3x3 matrix)
           t1p t2p, rectified translation vectors (3x1 matrix)
"""
def rectify_pair(K1, K2, R1, R2, t1, t2):
    # replace pass by your implementation
    #pass

    # 1: Optical Centers c1, c2
    c1 = -np.linalg.inv(R1) @ t1  #camera 1
    c2 = -np.linalg.inv(R2) @ t2  #camera 2

    # 2: Rectification Rotation Matrix Re
    # a) New x-axis (r1) along baseline direction
    r1 = (c2 - c1).flatten()
    r1 /= np.linalg.norm(r1)

    # b) New y-axis (r2) is perpendicular to r1 & optical axis direction
    # Baseline vector
    T = c2 - c1  
    # T is 1D
    T = T.flatten()  
    # Cross-product equivalent for y-axis
    r2 = np.array([-T[1], T[0], 0])  
    # Normalize
    r2 /= np.linalg.norm(r2)  

    # c) New z-axis (r3) is orthogonal to x and y
    r3 = np.cross(r1, r2)

    # new rotation matrix
    Re = np.vstack([r1, r2, r3])

    # 3: new rotation matrices
    R1p = Re @ R1
    R2p = Re @ R2

    # 4: new intrinsic matrices
    K1p = K2p = K2.copy()

    # 5: new translation vectors
    t1p = -R1p @ c1
    t2p = -R2p @ c2

    # 6: rectification matrices
    M1 = (K1p @ R1p) @ np.linalg.inv(K1 @ R1)
    M2 = (K2p @ R2p) @ np.linalg.inv(K2 @ R2)

    return M1, M2, K1p, K2p, R1p, R2p, t1p, t2p


"""
Q3.2.2 Disparity Map
       [I] im1, image 1 (H1xW1 matrix)
           im2, image 2 (H2xW2 matrix)
           max_disp, scalar maximum disparity value
           win_size, scalar window size value
       [O] dispM, disparity map (H1xW1 matrix)
"""
def get_disparity(im1, im2, max_disp, win_size):
    # replace pass by your implementation
    #pass
    H, W = im1.shape
    w = win_size // 2
    dispM = np.zeros((H, W), dtype=np.uint8)

    # window kernel
    window = np.ones((win_size, win_size), dtype=np.float32)

    # Init. SSD array -> storing results
    min_ssd = np.full((H, W), np.inf, dtype=np.float32)

    for d in range(max_disp + 1):
        # Shift right image by d pixels (leftward)
        shifted_im2 = np.roll(im2, -d, axis=1)

        # SSD using convolution for fast window-based sum
        ssd = (im1 - shifted_im2) ** 2
        ssd_sum = scipy.signal.correlate2d(ssd, window, mode='same')

        # Update disparity  
        # SSD min!
        mask = ssd_sum < min_ssd
        dispM[mask] = d
        min_ssd[mask] = ssd_sum[mask]

    return dispM


"""
Q3.2.3 Depth Map
       [I] dispM, disparity map (H1xW1 matrix)
           K1 K2, camera matrices (3x3 matrix)
           R1 R2, rotation matrices (3x3 matrix)
           t1 t2, translation vectors (3x1 matrix)
       [O] depthM, depth map (H1xW1 matrix)
"""
def get_depth(dispM, K1, K2, R1, R2, t1, t2):
    # replace pass by your implementation
    #pass

    c1 = -R1.T @ t1  # first camera
    c2 = -R2.T @ t2  # second camera
    # Baseline distance
    b = np.linalg.norm(c2 - c1)  

    # Focal length 
    # (assume f = K1[0, 0] = fx)
    f = K1[0, 0]

    # Avoid division by 0: 
    # Set depth to 0 where disparity is 0
    depthM = np.zeros_like(dispM, dtype=np.float32)
    # mask: valid disparity values
    valid_disp = dispM > 0  

    # depth = (b * f) / disparity
    depthM[valid_disp] = (b * f) / dispM[valid_disp]

    return depthM



"""
Q3.3.1 Camera Matrix Estimation
       [I] x, 2D points (Nx2 matrix)
           X, 3D points (Nx3 matrix)
       [O] P, camera matrix (3x4 matrix)
"""
def estimate_pose(x, X):
    # replace pass by your implementation
    #pass
    N = x.shape[0]  # correspondences
    A = []

    for i in range(N):
        X_w, Y_w, Z_w = X[i]  # 3D world coordinates
        x_i, y_i = x[i]  # 2D image coordinates

        # 2 rows per point
        A.append([X_w, Y_w, Z_w, 1, 0, 0, 0, 0, -x_i * X_w, -x_i * Y_w, -x_i * Z_w, -x_i])
        A.append([0, 0, 0, 0, X_w, Y_w, Z_w, 1, -y_i * X_w, -y_i * Y_w, -y_i * Z_w, -y_i])

    A = np.array(A)  # list -> matrix

    # Solve w. SVD
    U, S, Vt = np.linalg.svd(A)
    # Last row of V (smallest singular value)
    P = Vt[-1].reshape(3, 4)  

    return P

"""
Q3.3.2 Camera Parameter Estimation
       [I] P, camera matrix (3x4 matrix)
       [O] K, camera intrinsics (3x3 matrix)
           R, camera extrinsics rotation (3x3 matrix)
           t, camera extrinsics translation (3x1 matrix)
"""
def estimate_params(P):
    # replace pass by your implementation
    #pass

    # camera center c w. SVD
    #_, _, vh = svd(P)
    # -> Euclidean coordinates
    #c = vh[-1, :3] / vh[-1, -1]  

    # Extract M (first 3x3 part of P) 
    # perform RQ decomposition
    K, R = rq(P[:, :3])

    # K has positive diagonal values
    # Normalize K so bottom-right value is 1
    #K /= K[-1, -1]  
    T = np.diag(np.sign(np.diag(K)))
    K = K @ T
    R = T @ R  

    # Re-normalize Rotation Matrix using SVD
    U, _, Vt = np.linalg.svd(R)
    # R is a proper rotation matrix (SO(3))
    R = U @ Vt  

    # translation t
    #t = -R @ c.reshape(-1, 1)
    K_inv = np.linalg.inv(K)
    t = K_inv @ P[:, 3].reshape(-1, 1)

    return K, R, t
    



