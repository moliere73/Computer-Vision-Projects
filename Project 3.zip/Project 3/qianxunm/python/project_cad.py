import numpy as np
import matplotlib.pyplot as plt
import submission as sub
import cv2

# 1. Load Data 
data = np.load("../data/pnp.npz", allow_pickle=True)
image = data["image"]
# Extract CAD model data
cadPoints, cadTriangles = data["cad"][0][0]  
# Adjust for MATLAB 1-based indexing
cadTriangles -= 1  
x, X = data["x"], data["X"]  # 2D-3D correspondences

# 2. Estimate Camera Parameters 
P = sub.estimate_pose(x, X)
K, R, t = sub.estimate_params(P)

# 3. Projection Function 
def project_points(points, P):
    """ Projects 3D points onto the image using camera matrix P. """
    points_h = np.hstack((points, np.ones((points.shape[0], 1))))  # ->homogeneous
    proj = (P @ points_h.T).T
    return proj[:, :2] / proj[:, 2, np.newaxis]  # Normalize

# 4. Project Given 3D Points 
projected_X = project_points(X, P)

# 5. Plot Given 2D Points & Projected 3D Points 
plt.figure(figsize=(10, 5))
plt.imshow(image, cmap="gray")
# Green circles
plt.scatter(x[:, 0], x[:, 1], color='green', marker='o', label="Given 2D Points")  
# Black crosses
plt.scatter(projected_X[:, 0], projected_X[:, 1], color='black', marker='x', label="Projected 3D Points")  
plt.legend()
plt.title("2D Points & Projected 3D Points")
plt.savefig("../results/cad_projection_2d.png")
plt.show()

#6. Visualize Rotated CAD Model 
fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111, projection='3d')
rotated_cad = (R @ cadPoints.T).T  # Rotate CAD model
ax.plot_trisurf(rotated_cad[:, 0], rotated_cad[:, 1], rotated_cad[:, 2], triangles=cadTriangles, color='blue', edgecolor='k')
ax.set_title("Rotated CAD Model")
plt.savefig("../results/cad_rotation_3d.png")
plt.show()

# 7. Project CAD Model onto Image 
projected_cad = project_points(cadPoints, P)

# 8. Overlay Projected CAD Model onto Image 
plt.figure(figsize=(10, 5))
plt.imshow(image, cmap="gray")
 # Red dots
plt.scatter(projected_cad[:, 0], projected_cad[:, 1], color='red', marker='.', label="Projected CAD Model") 
plt.legend()
plt.title("Projected CAD Model on Image")
plt.savefig("../results/cad_overlay.png")
plt.show()
