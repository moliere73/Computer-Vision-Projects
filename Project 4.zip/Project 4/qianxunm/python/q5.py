
import numpy as np

import skimage
import skimage.measure
import skimage.color
import skimage.restoration
import skimage.filters
import skimage.morphology
import skimage.segmentation

# takes a color image
# returns a list of bounding boxes and black_and_white image
def findLetters(image):
    bboxes = []
    #bw = None
    # insert processing in here
    # one idea estimate noise -> denoise -> greyscale -> threshold -> morphology -> label -> skip small boxes 
    # this can be 10 to 15 lines of code using skimage functions

    # 1: Denoise
    #denoised = skimage.restoration.denoise_bilateral(image, multichannel=True)
    denoised = skimage.restoration.denoise_bilateral(image, channel_axis=-1)


    # 2: -> grayscale
    gray = skimage.color.rgb2gray(denoised)

    # 3: Threshold the image -> binarize it
    thresh = skimage.filters.threshold_otsu(gray)
    bw = gray < thresh  # characters should be black (True), background white (False)

    # 4: Remove small objects & clean borders
    bw = skimage.morphology.opening(bw, skimage.morphology.square(3))
    bw = skimage.morphology.closing(bw, skimage.morphology.square(3))

    # 5: Label connected components
    label_image = skimage.measure.label(bw)

    # 6: Extract bounding boxes
    for region in skimage.measure.regionprops(label_image):
        if region.area < 100:  # filter out small components (noise)
            continue
        minr, minc, maxr, maxc = region.bbox
        bboxes.append([minr, minc, maxr, maxc])

    # 7: boolean mask -> float image w. characters black (0.0), background white (1.0)
    bw = bw.astype(np.float32)
    
    return bboxes, bw
