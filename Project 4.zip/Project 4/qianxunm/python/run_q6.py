# Q6.1.1 - Train a fully-connected neural network on NIST36 using PyTorch
'''
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import matplotlib.pyplot as plt
import numpy as np
from torch.utils.data import DataLoader, TensorDataset
import scipy.io

# Load .mat files
train_data = scipy.io.loadmat('../data/nist36_train.mat')
valid_data = scipy.io.loadmat('../data/nist36_valid.mat')

X_train = train_data['train_data']
y_train = np.argmax(train_data['train_labels'], axis=1)

X_val = valid_data['valid_data']
y_val = np.argmax(valid_data['valid_labels'], axis=1)

# Convert to PyTorch tensors
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.long)
X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
y_val_tensor = torch.tensor(y_val, dtype=torch.long)

# Create DataLoaders
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=64)

# Define the model
class NIST36Net(nn.Module):
    def __init__(self):
        super(NIST36Net, self).__init__()
        self.fc1 = nn.Linear(1024, 128)
        self.fc2 = nn.Linear(128, 36)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = NIST36Net()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training loop
epochs = 10
train_loss_list = []
train_acc_list = []

for epoch in range(epochs):
    model.train()
    running_loss = 0
    correct = 0
    total = 0
    
    for images, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

    avg_loss = running_loss / len(train_loader)
    accuracy = correct / total
    train_loss_list.append(avg_loss)
    train_acc_list.append(accuracy)

    print(f"Epoch {epoch+1}/{epochs}, Loss: {avg_loss:.4f}, Accuracy: {accuracy:.4f}")

# Plot training loss and accuracy
plt.figure(figsize=(12,5))
plt.subplot(1, 2, 1)
plt.plot(train_loss_list, label='Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss')
plt.grid()

plt.subplot(1, 2, 2)
plt.plot(train_acc_list, label='Training Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.title('Training Accuracy')
plt.grid()

plt.tight_layout()
plt.savefig('q6_train_curves.png')
plt.close()
'''
'''
import os
import numpy as np
import matplotlib
matplotlib.use('agg') 
import matplotlib.pyplot as plt
import matplotlib.patches

import skimage
import skimage.measure
import skimage.color
import skimage.restoration
import skimage.io
import skimage.filters
import skimage.morphology
import skimage.segmentation
import skimage.transform

from nn import *
from q5 import *
# do not include any more libraries here!
# no opencv, no sklearn, etc!
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

import pickle
import string
letters = np.array([_ for _ in string.ascii_uppercase[:26]] + [str(_) for _ in range(10)])
params = pickle.load(open('q3_weights.pickle','rb'))

for img in sorted(os.listdir('../images')):
    im1 = skimage.img_as_float(skimage.io.imread(os.path.join('../images', img)))
    bboxes, bw = findLetters(im1)

    # Plot bounding boxes on the binarized image
    plt.imshow(bw, cmap='gray')
    for bbox in bboxes:
        minr, minc, maxr, maxc = bbox
        rect = matplotlib.patches.Rectangle((minc, minr), maxc - minc, maxr - minr,
                                            fill=False, edgecolor='red', linewidth=2)
        plt.gca().add_patch(rect)
    plt.title(f"Detected letters in {img}")
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(f"detected_{img}")
    plt.close()

    # Sort bounding boxes by rows using the y-coordinate of their centers
    bboxes = sorted(bboxes, key=lambda b: (b[0] + b[2]) // 2)
    lines = []
    current_line = []
    threshold = 40
    for bbox in bboxes:
        if not current_line:
            current_line.append(bbox)
        elif abs(((bbox[0] + bbox[2]) // 2) - ((current_line[-1][0] + current_line[-1][2]) // 2)) < threshold:
            current_line.append(bbox)
        else:
            lines.append(sorted(current_line, key=lambda b: b[1]))
            current_line = [bbox]
    if current_line:
        lines.append(sorted(current_line, key=lambda b: b[1]))

    # Sort lines from top to bottom
    lines = sorted(lines, key=lambda line: np.mean([(b[0] + b[2]) for b in line]) / 2)

    # Extract and classify characters
    out_text = []
    for line in lines:
        line_text = ''
        for bbox in line:
            minr, minc, maxr, maxc = bbox
            char_img = bw[minr:maxr, minc:maxc]
            height, width = char_img.shape
            size = max(height, width)
            pad_vert = (size - height)
            pad_horz = (size - width)
            padded = np.pad(char_img,
                            ((pad_vert // 2, pad_vert - pad_vert // 2),
                             (pad_horz // 2, pad_horz - pad_horz // 2)),
                            mode='constant', constant_values=1.0)

            resized = skimage.transform.resize(padded, (32, 32), anti_aliasing=True)
            resized = (1.0 - resized).T.reshape(1, -1)  # Invert and transpose

            h1 = forward(resized, params, 'layer1')
            probs = forward(h1, params, 'output', softmax)
            pred = np.argmax(probs)
            line_text += letters[pred]
        out_text.append(line_text)

    # Print extracted text
    print(f"Image: {img}")
    for line in out_text:
        print(line)
    print("\n")

    # Save pretty text image
    fig, ax = plt.subplots()
    fig.set_facecolor('black')
    ax.set_facecolor('black')
    for i, line in enumerate(out_text):
        ax.text(0.01, 1 - 0.1 * i, line, fontsize=14, color='white', family='monospace')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title(f"Predicted text for {img}", color='white')
    plt.tight_layout()
    plt.savefig(f"text_{img}")
    plt.close()
'''
'''
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt

# Define CNN architecture for CIFAR-10
class CIFAR10CNN(nn.Module):
    def __init__(self):
        super(CIFAR10CNN, self).__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 8 * 8, 256)
        self.fc2 = nn.Linear(256, 10)

    def forward(self, x):
        x = self.pool(nn.ReLU()(self.conv1(x)))
        x = self.pool(nn.ReLU()(self.conv2(x)))
        x = x.view(-1, 64 * 8 * 8)
        x = nn.ReLU()(self.fc1(x))
        x = self.fc2(x)
        return x

# Load CIFAR-10 dataset
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=64, shuffle=True)

# Instantiate model, loss, optimizer
model = CIFAR10CNN()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Train the model
epochs = 10
loss_history = []
acc_history = []

for epoch in range(epochs):
    running_loss = 0.0
    correct = 0
    total = 0
    for inputs, labels in trainloader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

    avg_loss = running_loss / len(trainloader)
    accuracy = correct / total
    loss_history.append(avg_loss)
    acc_history.append(accuracy)
    print(f"Epoch {epoch+1}/{epochs} \t Loss: {avg_loss:.4f} \t Accuracy: {accuracy:.4f}")

# Plot training metrics
plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.plot(loss_history, label="Loss")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.title("Training Loss")
plt.grid()

plt.subplot(1, 2, 2)
plt.plot(acc_history, label="Accuracy")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.title("Training Accuracy")
plt.grid()

plt.tight_layout()
plt.savefig("q6_cifar10_train_curves.png")
plt.close()
'''

'''
import os
import numpy as np
import matplotlib
matplotlib.use('agg') 
import matplotlib.pyplot as plt
import matplotlib.patches

import skimage
import skimage.measure
import skimage.color
import skimage.restoration
import skimage.io
import skimage.filters
import skimage.morphology
import skimage.segmentation
import skimage.transform

from nn import *
from q5 import *
# do not include any more libraries here!
# no opencv, no sklearn, etc!
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

import pickle
import string
letters = np.array([_ for _ in string.ascii_uppercase[:26]] + [str(_) for _ in range(10)])
params = pickle.load(open('q3_weights.pickle','rb'))

for img in sorted(os.listdir('../images')):
    im1 = skimage.img_as_float(skimage.io.imread(os.path.join('../images', img)))
    bboxes, bw = findLetters(im1)

    # Plot bounding boxes on the binarized image
    plt.imshow(bw, cmap='gray')
    for bbox in bboxes:
        minr, minc, maxr, maxc = bbox
        rect = matplotlib.patches.Rectangle((minc, minr), maxc - minc, maxr - minr,
                                            fill=False, edgecolor='red', linewidth=2)
        plt.gca().add_patch(rect)
    plt.title(f"Detected letters in {img}")
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(f"detected_{img}")
    plt.close()

    # Sort bounding boxes by rows using the y-coordinate of their centers
    bboxes = sorted(bboxes, key=lambda b: (b[0] + b[2]) // 2)
    lines = []
    current_line = []
    threshold = 40
    for bbox in bboxes:
        if not current_line:
            current_line.append(bbox)
        elif abs(((bbox[0] + bbox[2]) // 2) - ((current_line[-1][0] + current_line[-1][2]) // 2)) < threshold:
            current_line.append(bbox)
        else:
            lines.append(sorted(current_line, key=lambda b: b[1]))
            current_line = [bbox]
    if current_line:
        lines.append(sorted(current_line, key=lambda b: b[1]))

    # Sort lines from top to bottom
    lines = sorted(lines, key=lambda line: np.mean([(b[0] + b[2]) for b in line]) / 2)

    # Extract and classify characters
    out_text = []
    for line in lines:
        line_text = ''
        for bbox in line:
            minr, minc, maxr, maxc = bbox
            char_img = bw[minr:maxr, minc:maxc]
            height, width = char_img.shape
            size = max(height, width)
            pad_vert = (size - height)
            pad_horz = (size - width)
            padded = np.pad(char_img,
                            ((pad_vert // 2, pad_vert - pad_vert // 2),
                             (pad_horz // 2, pad_horz - pad_horz // 2)),
                            mode='constant', constant_values=1.0)

            resized = skimage.transform.resize(padded, (32, 32), anti_aliasing=True)
            resized = (1.0 - resized).T.reshape(1, -1)  # Invert and transpose

            h1 = forward(resized, params, 'layer1')
            probs = forward(h1, params, 'output', softmax)
            pred = np.argmax(probs)
            line_text += letters[pred]
        out_text.append(line_text)

    # Print extracted text
    print(f"Image: {img}")
    for line in out_text:
        print(line)
    print("\n")

    # Save pretty text image
    fig, ax = plt.subplots()
    fig.set_facecolor('black')
    ax.set_facecolor('black')
    for i, line in enumerate(out_text):
        ax.text(0.01, 1 - 0.1 * i, line, fontsize=14, color='white', family='monospace')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title(f"Predicted text for {img}", color='white')
    plt.tight_layout()
    plt.savefig(f"text_{img}")
    plt.close()

# Dummy SUN dataset generator
from PIL import Image, ImageDraw

def create_dummy_sun_dataset(base_path='../data/sun', categories=['kitchen', 'bedroom'], num_per_cat=10):
    os.makedirs(base_path, exist_ok=True)
    for split in ['train', 'val']:
        for cat in categories:
            dir_path = os.path.join(base_path, split, cat)
            os.makedirs(dir_path, exist_ok=True)
            for i in range(num_per_cat):
                img = Image.new('RGB', (64, 64), color=(np.random.randint(255),
                                                        np.random.randint(255),
                                                        np.random.randint(255)))
                draw = ImageDraw.Draw(img)
                draw.text((10, 25), cat[:2], fill=(255, 255, 255))
                img.save(os.path.join(dir_path, f'{cat}_{i}.png'))
'''

import os
import numpy as np
import matplotlib
matplotlib.use('agg') 
import matplotlib.pyplot as plt
import matplotlib.patches

import skimage
import skimage.measure
import skimage.color
import skimage.restoration
import skimage.io
import skimage.filters
import skimage.morphology
import skimage.segmentation
import skimage.transform

from nn import *
from q5 import *
# do not include any more libraries here!
# no opencv, no sklearn, etc!
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

import pickle
import string
letters = np.array([_ for _ in string.ascii_uppercase[:26]] + [str(_) for _ in range(10)])
params = pickle.load(open('q3_weights.pickle','rb'))

for img in sorted(os.listdir('../images')):
    im1 = skimage.img_as_float(skimage.io.imread(os.path.join('../images', img)))
    bboxes, bw = findLetters(im1)

    # Plot bounding boxes on the binarized image
    plt.imshow(bw, cmap='gray')
    for bbox in bboxes:
        minr, minc, maxr, maxc = bbox
        rect = matplotlib.patches.Rectangle((minc, minr), maxc - minc, maxr - minr,
                                            fill=False, edgecolor='red', linewidth=2)
        plt.gca().add_patch(rect)
    plt.title(f"Detected letters in {img}")
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(f"detected_{img}")
    plt.close()

    # Sort bounding boxes by rows using the y-coordinate of their centers
    bboxes = sorted(bboxes, key=lambda b: (b[0] + b[2]) // 2)
    lines = []
    current_line = []
    threshold = 40
    for bbox in bboxes:
        if not current_line:
            current_line.append(bbox)
        elif abs(((bbox[0] + bbox[2]) // 2) - ((current_line[-1][0] + current_line[-1][2]) // 2)) < threshold:
            current_line.append(bbox)
        else:
            lines.append(sorted(current_line, key=lambda b: b[1]))
            current_line = [bbox]
    if current_line:
        lines.append(sorted(current_line, key=lambda b: b[1]))

    # Sort lines from top to bottom
    lines = sorted(lines, key=lambda line: np.mean([(b[0] + b[2]) for b in line]) / 2)

    # Extract and classify characters
    out_text = []
    for line in lines:
        line_text = ''
        for bbox in line:
            minr, minc, maxr, maxc = bbox
            char_img = bw[minr:maxr, minc:maxc]
            height, width = char_img.shape
            size = max(height, width)
            pad_vert = (size - height)
            pad_horz = (size - width)
            padded = np.pad(char_img,
                            ((pad_vert // 2, pad_vert - pad_vert // 2),
                             (pad_horz // 2, pad_horz - pad_horz // 2)),
                            mode='constant', constant_values=1.0)

            resized = skimage.transform.resize(padded, (32, 32), anti_aliasing=True)
            resized = (1.0 - resized).T.reshape(1, -1)  # Invert and transpose

            h1 = forward(resized, params, 'layer1')
            probs = forward(h1, params, 'output', softmax)
            pred = np.argmax(probs)
            line_text += letters[pred]
        out_text.append(line_text)

    # Print extracted text
    print(f"Image: {img}")
    for line in out_text:
        print(line)
    print("\n")

    # Save pretty text image
    fig, ax = plt.subplots()
    fig.set_facecolor('black')
    ax.set_facecolor('black')
    for i, line in enumerate(out_text):
        ax.text(0.01, 1 - 0.1 * i, line, fontsize=14, color='white', family='monospace')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title(f"Predicted text for {img}", color='white')
    plt.tight_layout()
    plt.savefig(f"text_{img}")
    plt.close()

# Updated Q6.1.4 CNN model training for SUN scene classification

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torch.utils.data import DataLoader

# Dummy dataset creation for SUN classification
from PIL import Image, ImageDraw

def create_dummy_sun_dataset(base_path='../data/sun', categories=['kitchen', 'bedroom'], num_per_cat=10):
    os.makedirs(base_path, exist_ok=True)
    for split in ['train', 'val']:
        for cat in categories:
            dir_path = os.path.join(base_path, split, cat)
            os.makedirs(dir_path, exist_ok=True)
            for i in range(num_per_cat):
                img = Image.new('RGB', (64, 64), color=(np.random.randint(255),
                                                        np.random.randint(255),
                                                        np.random.randint(255)))
                draw = ImageDraw.Draw(img)
                draw.text((10, 25), cat[:2], fill=(255, 255, 255))
                img.save(os.path.join(dir_path, f'{cat}_{i}.png'))

# create_dummy_sun_dataset()  # Uncomment to generate dataset if needed

transform = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor()
])

train_dataset = datasets.ImageFolder('../data/sun/train', transform=transform)
val_dataset = datasets.ImageFolder('../data/sun/val', transform=transform)
train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=8)

# Define a simple CNN
class SunCNN(nn.Module):
    def __init__(self):
        super(SunCNN, self).__init__()
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.fc1 = nn.Linear(32 * 16 * 16, 64)
        self.fc2 = nn.Linear(64, len(train_dataset.classes))

    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = x.view(x.size(0), -1)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = SunCNN()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training loop
for epoch in range(5):
    model.train()
    running_loss = 0
    correct = 0
    total = 0
    for inputs, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

    print(f"Epoch {epoch+1} Loss: {running_loss/len(train_loader):.4f} Accuracy: {correct/total:.4f}")