import numpy as np
from nn import *
from util import *
import copy

# Generate fake data
g0 = np.random.multivariate_normal([3.6, 40], [[0.05, 0], [0, 10]], 10)
g1 = np.random.multivariate_normal([3.9, 10], [[0.01, 0], [0, 5]], 10)
g2 = np.random.multivariate_normal([3.4, 30], [[0.25, 0], [0, 5]], 10)
g3 = np.random.multivariate_normal([2.0, 10], [[0.5, 0], [0, 10]], 10)
x = np.vstack([g0, g1, g2, g3])

y_idx = np.array([0]*10 + [1]*10 + [2]*10 + [3]*10)
y = np.zeros((y_idx.shape[0], y_idx.max()+1))
y[np.arange(y_idx.shape[0]), y_idx] = 1

params = {}
initialize_weights(2, 25, params, 'layer1')
initialize_weights(25, 4, params, 'output')

assert params['Wlayer1'].shape == (2, 25)
assert params['blayer1'].shape == (25,)

print("{}, {:.2f}".format(params['blayer1'].sum(), params['Wlayer1'].std()**2))
print("{}, {:.2f}".format(params['boutput'].sum(), params['Woutput'].std()**2))

# Sigmoid test
test = sigmoid(np.array([-1000, 1000]))
print('should be zero and one\t', test.min(), test.max())

# Forward pass
h1 = forward(x, params, 'layer1')
print(h1.shape)
probs = forward(h1, params, 'output', softmax)
print(probs.min(), min(probs.sum(1)), max(probs.sum(1)), probs.shape)

# Loss
loss, acc = compute_loss_and_acc(y, probs)
print("{}, {:.2f}".format(loss, acc))

# Backprop setup
delta1 = probs.copy()
delta1[np.arange(probs.shape[0]), y_idx] -= 1
delta2 = backwards(delta1, params, 'output', linear_deriv)
backwards(delta2, params, 'layer1', sigmoid_deriv)

for k, v in sorted(params.items()):
    if 'grad' in k:
        name = k.split('_')[1]
        print(name, v.shape, params[name].shape)

# Batch generation
batches = get_random_batches(x, y, 5)
print([_[0].shape[0] for _ in batches])

# Training loop
max_iters = 500
learning_rate = 1e-3
for itr in range(max_iters):
    total_loss = 0
    avg_acc = 0
    for xb, yb in batches:
        h1 = forward(xb, params, 'layer1')
        probs = forward(h1, params, 'output', softmax)
        loss, acc = compute_loss_and_acc(yb, probs)
        total_loss += loss
        avg_acc += acc

        delta = probs - yb
        delta2 = backwards(delta, params, 'output', linear_deriv)
        backwards(delta2, params, 'layer1', sigmoid_deriv)

        params['Wlayer1'] -= learning_rate * params['grad_Wlayer1']
        params['blayer1'] -= learning_rate * params['grad_blayer1']
        params['Woutput'] -= learning_rate * params['grad_Woutput']
        params['boutput'] -= learning_rate * params['grad_boutput']

    avg_acc /= len(batches)
    total_loss /= len(batches)
    if itr % 100 == 0:
        print("itr: {:02d} \t loss: {:.2f} \t acc : {:.2f}".format(itr, total_loss, avg_acc))

# Q3.5.1 - Gradient checking
h1 = forward(x, params, 'layer1')
probs = forward(h1, params, 'output', softmax)
loss, _ = compute_loss_and_acc(y, probs)
delta = probs - y
delta2 = backwards(delta, params, 'output', linear_deriv)
backwards(delta2, params, 'layer1', sigmoid_deriv)

params_orig = copy.deepcopy(params)
eps = 1e-6

for k in list(params.keys()):
    if not (k.startswith('W') or k.startswith('b')):
        continue
    v = params[k]
    grad_v = np.zeros_like(v)
    it = np.nditer(v, flags=['multi_index'], op_flags=['readwrite'])
    while not it.finished:
        idx = it.multi_index
        old_val = v[idx]

        v[idx] = old_val + eps
        h1 = forward(x, params, 'layer1')
        probs = forward(h1, params, 'output', softmax)
        loss_plus, _ = compute_loss_and_acc(y, probs)

        v[idx] = old_val - eps
        h1 = forward(x, params, 'layer1')
        probs = forward(h1, params, 'output', softmax)
        loss_minus, _ = compute_loss_and_acc(y, probs)

        grad_v[idx] = (loss_plus - loss_minus) / (2 * eps)
        v[idx] = old_val
        it.iternext()

    params['grad_' + k] = grad_v

total_error = 0
for k in params.keys():
    if k.startswith('grad_'):
        base_k = k.replace('grad_', '')
        if base_k not in params_orig:
            continue
        err = np.abs(params[k] - params_orig[k]) / np.maximum(np.abs(params[k]) + 1e-8, np.abs(params_orig[k]) + 1e-8)
        err = err.sum()
        print(f'{k} relative error: {err:.2e}')
        total_error += err

print('Total relative error: {:.2e}'.format(total_error))
