import numpy as np
import scipy.io
from nn import *
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid
import pickle
import string

# Load data
train_data = scipy.io.loadmat('../data/nist36_train.mat')
valid_data = scipy.io.loadmat('../data/nist36_valid.mat')
test_data = scipy.io.loadmat('../data/nist36_test.mat')

train_x, train_y = train_data['train_data'], train_data['train_labels']
valid_x, valid_y = valid_data['valid_data'], valid_data['valid_labels']
test_x, test_y = test_data['test_data'], test_data['test_labels']

# Normalize data
train_x = (train_x - np.mean(train_x)) / np.std(train_x)
valid_x = (valid_x - np.mean(valid_x)) / np.std(valid_x)
test_x = (test_x - np.mean(test_x)) / np.std(test_x)

# Hyperparameters
max_iters = 50
batch_size = 32
learning_rate = 0.005
hidden_size = 64

# Initialize parameters
params = {}
n_input = train_x.shape[1]
n_output = train_y.shape[1]
initialize_weights(n_input, hidden_size, params, 'layer1')
initialize_weights(hidden_size, n_output, params, 'output')

# Track metrics
train_acc_data, valid_acc_data = [], []
train_loss_data, valid_loss_data = [], []

def safe_relu_deriv(x):
    return (x > 0).astype(np.float64)

# Training loop
for itr in range(max_iters):
    batches = get_random_batches(train_x, train_y, batch_size)
    total_loss, total_acc = 0, 0
    for xb, yb in batches:
        h1 = forward(xb, params, 'layer1', activation=relu)
        probs = forward(h1, params, 'output', activation=softmax)
        loss, acc = compute_loss_and_acc(yb, probs)
        total_loss += loss
        total_acc += acc

        delta1 = probs - yb
        delta2 = backwards(delta1, params, 'output', activation_deriv=linear_deriv)
        backwards(delta2, params, 'layer1', activation_deriv=safe_relu_deriv)

        for key in ['Wlayer1', 'blayer1', 'Woutput', 'boutput']:
            params[key] -= learning_rate * params['grad_' + key]

    total_acc /= len(batches)
    total_loss /= train_x.shape[0]

    h1_valid = forward(valid_x, params, 'layer1', activation=relu)
    probs_valid = forward(h1_valid, params, 'output', activation=softmax)
    loss_valid, acc_valid = compute_loss_and_acc(valid_y, probs_valid)
    loss_valid /= valid_x.shape[0]

    train_acc_data.append(total_acc)
    valid_acc_data.append(acc_valid)
    train_loss_data.append(total_loss)
    valid_loss_data.append(loss_valid)

    if itr % 2 == 0:
        print(f"itr: {itr:02d} \t loss: {total_loss:.2f} \t acc : {total_acc:.2f}")

print("Final training accuracy:", total_acc)

# Accuracy plot
plt.figure()
plt.title("Accuracy")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.plot(train_acc_data, label="Train Acc")
plt.plot(valid_acc_data, label="Valid Acc")
plt.legend()
plt.tight_layout()
plt.show()

# Loss plot
plt.figure()
plt.title("Loss")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.plot(train_loss_data, label="Train Loss")
plt.plot(valid_loss_data, label="Valid Loss")
plt.legend()
plt.tight_layout()
plt.show()

# Final validation accuracy
h1_valid = forward(valid_x, params, 'layer1', activation=relu)
probs_valid = forward(h1_valid, params, 'output', activation=softmax)
_, valid_acc = compute_loss_and_acc(valid_y, probs_valid)
print("Validation accuracy:", valid_acc)

# Final test accuracy
h1_test = forward(test_x, params, 'layer1', activation=relu)
probs_test = forward(h1_test, params, 'output', activation=softmax)
_, test_acc = compute_loss_and_acc(test_y, probs_test)
print("Test accuracy:", test_acc)

# Save parameters
saved_params = {k: v for k, v in params.items() if '_' not in k}
with open('q3_weights.pickle', 'wb') as handle:
    pickle.dump(saved_params, handle, protocol=pickle.HIGHEST_PROTOCOL)

'''
# Q4.3 - Visualize weights
W_firstlayer = params['Wlayer1']
fig = plt.figure()
grid = ImageGrid(fig, 111, nrows_ncols=(8, 8), axes_pad=0.0)
for i in range(W_firstlayer.shape[1]):
    grid[i].imshow(W_firstlayer[:, i].reshape(32, 32), cmap='gray')
    grid[i].axis('off')
plt.suptitle("First Layer Weights")
plt.tight_layout()
plt.show()
'''

# Q4.3 - Visualize and Compare Initial vs Trained Weights

# Trained weights
W_init = params['Wlayer1'].copy()

W_trained = params['Wlayer1']

# Save a side-by-side comparison for your writeup
def visualize_weight_comparison(W_init, W_trained, filename, title="First Layer Weights: Init vs Trained"):
    fig = plt.figure(figsize=(12, 6))
    grid = ImageGrid(fig, 111, nrows_ncols=(2, 8), axes_pad=0.2)

    for i in range(8):
        grid[i].imshow(W_init[:, i].reshape(32, 32), cmap='gray')
        grid[i].axis('off')
        grid[i + 8].imshow(W_trained[:, i].reshape(32, 32), cmap='gray')
        grid[i + 8].axis('off')

    grid[0].set_title('Before Training')
    grid[8].set_title('After Training')
    plt.suptitle(title)
    plt.tight_layout()
    plt.savefig(filename)
    plt.show()

# Show full trained weights (same as original code)
fig = plt.figure()
grid = ImageGrid(fig, 111, nrows_ncols=(8, 8), axes_pad=0.0)
for i in range(W_trained.shape[1]):
    grid[i].imshow(W_trained[:, i].reshape(32, 32), cmap='gray')
    grid[i].axis('off')
plt.suptitle("First Layer Weights After Training")
plt.tight_layout()
plt.show()

# Save side-by-side image
visualize_weight_comparison(W_init, W_trained, "weights_comparison.png")


# Q4.4 - Confusion matrix
confusion_matrix = np.zeros((train_y.shape[1], train_y.shape[1]))
y_pred = np.argmax(probs_test, axis=1)
y_true = np.argmax(test_y, axis=1)

for i in range(test_y.shape[0]):
    confusion_matrix[y_true[i], y_pred[i]] += 1

import string
plt.figure(figsize=(10, 8))
plt.imshow(confusion_matrix, interpolation='nearest', cmap='viridis')
plt.title("Confusion Matrix")
plt.grid(False)
plt.colorbar()
plt.xticks(np.arange(36), list(string.ascii_uppercase) + [str(i) for i in range(10)], rotation=90)
plt.yticks(np.arange(36), list(string.ascii_uppercase) + [str(i) for i in range(10)])
plt.tight_layout()
plt.show()