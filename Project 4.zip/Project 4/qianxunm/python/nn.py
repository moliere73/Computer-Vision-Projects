import numpy as np
from util import *

# Q 3.1.2
def initialize_weights(in_size, out_size, params, name=''):
    scale = np.sqrt(6.0 / (in_size + out_size))
    W = np.random.uniform(-scale, scale, (in_size, out_size))
    b = np.zeros(out_size)
    params['W' + name] = W
    params['b' + name] = b

# Numerically stable sigmoid
def sigmoid(x):
    #return np.where(x >= 0, 1 / (1 + np.exp(-x)), np.exp(x) / (1 + np.exp(x)))
    out = np.empty_like(x)
    pos_mask = x >= 0
    neg_mask = ~pos_mask
    out[pos_mask] = 1 / (1 + np.exp(-x[pos_mask]))
    exp_x = np.exp(x[neg_mask])
    out[neg_mask] = exp_x / (1 + exp_x)
    return out

# Q 3.2.1 - Forward pass with activation
def forward(X, params, name='', activation=sigmoid):
    W = params['W' + name]
    b = params['b' + name]
    pre_act = X @ W + b
    post_act = activation(pre_act)
    params['cache_' + name] = (X, pre_act, post_act)
    return post_act

# Q 3.2.2 - Softmax row-wise
def softmax(x):
    x_shifted = x - np.max(x, axis=1, keepdims=True)
    exp_x = np.exp(x_shifted)
    return exp_x / np.sum(exp_x, axis=1, keepdims=True)

# Q 3.2.3 - Loss + accuracy
def compute_loss_and_acc(y, probs):
    loss = -np.sum(y * np.log(probs + 1e-10))
    pred = np.argmax(probs, axis=1)
    true = np.argmax(y, axis=1)
    acc = np.mean(pred == true)
    return loss, acc

# Given
def sigmoid_deriv(post_act):
    return post_act * (1.0 - post_act)

def linear_deriv(post_act):
    return np.ones_like(post_act)

# Q 3.3.1 - Backprop
def backwards(delta, params, name='', activation_deriv=sigmoid_deriv):
    W = params['W' + name]
    b = params['b' + name]
    X, pre_act, post_act = params['cache_' + name]

    derivative = activation_deriv(post_act)
    delta *= derivative

    grad_W = X.T @ delta
    grad_b = np.sum(delta, axis=0)
    grad_X = delta @ W.T

    params['grad_W' + name] = grad_W
    params['grad_b' + name] = grad_b
    return grad_X

# Q 3.4.1 - Mini-batches
def get_random_batches(x, y, batch_size):
    batches = []
    N = x.shape[0]
    indices = np.arange(N)
    np.random.shuffle(indices)

    for i in range(0, N, batch_size):
        batch_idx = indices[i:i + batch_size]
        batches.append((x[batch_idx], y[batch_idx]))
    return batches
