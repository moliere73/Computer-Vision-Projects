import os
import numpy as np
import matplotlib
matplotlib.use('agg') 
import matplotlib.pyplot as plt
import matplotlib.patches

import skimage
import skimage.measure
import skimage.color
import skimage.restoration
import skimage.io
import skimage.filters
import skimage.morphology
import skimage.segmentation
import skimage.transform

from nn import *
from q5 import *
# do not include any more libraries here!
# no opencv, no sklearn, etc!
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

import pickle
import string
letters = np.array([_ for _ in string.ascii_uppercase[:26]] + [str(_) for _ in range(10)])
params = pickle.load(open('q3_weights.pickle','rb'))

for img in sorted(os.listdir('../images')):
    im1 = skimage.img_as_float(skimage.io.imread(os.path.join('../images', img)))
    bboxes, bw = findLetters(im1)

    # Plot bounding boxes on the binarized image
    plt.imshow(bw, cmap='gray')
    for bbox in bboxes:
        minr, minc, maxr, maxc = bbox
        rect = matplotlib.patches.Rectangle((minc, minr), maxc - minc, maxr - minr,
                                            fill=False, edgecolor='red', linewidth=2)
        plt.gca().add_patch(rect)
    plt.title(f"Detected letters in {img}")
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(f"detected_{img}")
    plt.close()

    # Sort bounding boxes by rows using the y-coordinate of their centers
    bboxes = sorted(bboxes, key=lambda b: (b[0] + b[2]) // 2)
    lines = []
    current_line = []
    threshold = 40
    for bbox in bboxes:
        if not current_line:
            current_line.append(bbox)
        elif abs(((bbox[0] + bbox[2]) // 2) - ((current_line[-1][0] + current_line[-1][2]) // 2)) < threshold:
            current_line.append(bbox)
        else:
            lines.append(sorted(current_line, key=lambda b: b[1]))
            current_line = [bbox]
    if current_line:
        lines.append(sorted(current_line, key=lambda b: b[1]))

    # Sort lines from top to bottom
    lines = sorted(lines, key=lambda line: np.mean([(b[0] + b[2]) for b in line]) / 2)

    # Extract and classify characters
    out_text = []
    for line in lines:
        line_text = ''
        for bbox in line:
            minr, minc, maxr, maxc = bbox
            char_img = bw[minr:maxr, minc:maxc]
            height, width = char_img.shape
            size = max(height, width)
            pad_vert = (size - height)
            pad_horz = (size - width)
            padded = np.pad(char_img,
                            ((pad_vert // 2, pad_vert - pad_vert // 2),
                             (pad_horz // 2, pad_horz - pad_horz // 2)),
                            mode='constant', constant_values=1.0)

            resized = skimage.transform.resize(padded, (32, 32), anti_aliasing=True)
            resized = (1.0 - resized).T.reshape(1, -1)  # Invert and transpose

            h1 = forward(resized, params, 'layer1')
            probs = forward(h1, params, 'output', softmax)
            pred = np.argmax(probs)
            line_text += letters[pred]
        out_text.append(line_text)

    # Print extracted text
    print(f"Image: {img}")
    for line in out_text:
        print(line)
    print("\n")

    # Save pretty text image
    fig, ax = plt.subplots()
    fig.set_facecolor('black')
    ax.set_facecolor('black')
    for i, line in enumerate(out_text):
        ax.text(0.01, 1 - 0.1 * i, line, fontsize=14, color='white', family='monospace')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title(f"Predicted text for {img}", color='white')
    plt.tight_layout()
    plt.savefig(f"text_{img}")
    plt.close()
