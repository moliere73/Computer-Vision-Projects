import numpy as np

def myImageFilter(img0, h, mode='edge'):
    # YOUR CODE HERE

    # Ensure the kernel is flipped 
    # (correlation -> convolution)
    h = np.flipud(np.fliplr(h)) 

    # image dimensions
    img_h, img_w = img0.shape
    # kernel dimensions
    kernel_h, kernel_w = h.shape
    # padding size
    pad_h, pad_w = kernel_h // 2, kernel_w // 2  

    # Pad image w. edge  
    # replicates nearest pixels
    img_padded = np.pad(img0, ((pad_h, pad_h), (pad_w, pad_w)), mode='edge')

    # Init. output image
    img1 = np.zeros_like(img0, dtype=np.float64)

    # Use NumPy vectorization 
    # -> efficient convolution
    for i in range(kernel_h):
        for j in range(kernel_w):
            img1 += img_padded[i:i + img_h, j:j + img_w] * h[i, j]

    return img1
