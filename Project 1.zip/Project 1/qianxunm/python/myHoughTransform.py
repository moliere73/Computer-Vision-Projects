import numpy as np

def myHoughTransform(image, rho_res, theta_res):
    #dimensions
    img_h, img_w = image.shape

    # Compute maximum possible rho value
    max_rho = int(np.ceil(np.hypot(img_h, img_w) / rho_res))
    
    theta_scale = np.arange(0, 2 * np.pi, theta_res)
    rho_scale = np.linspace(0, max_rho * rho_res, max_rho, endpoint=False)
    
    # Init. accumulator
    accumulator = np.zeros((max_rho, len(theta_scale)), dtype=int)
    
    # Precompute cos & sin values -> efficiency
    cos_theta = np.cos(theta_scale)
    sin_theta = np.sin(theta_scale)
    
    # Hough Transform w. vectorized operations
    # Get edge pixel coordinates
    y_idxs, x_idxs = np.nonzero(image)  
    for x, y in zip(x_idxs, y_idxs):
        rhos = x * cos_theta + y * sin_theta
        # Mask: ignore negative rho values
        valid_rhos = (rhos >= 0)  
        rho_idxs = (rhos[valid_rhos] // rho_res).astype(int)
        accumulator[rho_idxs, np.where(valid_rhos)[0]] += 1  

    return accumulator, rho_scale, theta_scale
