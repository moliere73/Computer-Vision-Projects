import numpy as np
from scipy import signal
from myImageFilter import myImageFilter

def get_closest_angle_index(slope):
    angles = np.array([0, 45, 90, 135, 180])
    # min index retrieval -> efficiency
    return np.argmin(np.abs(angles - slope))  

def myEdgeFilter(img0, sigma):
    #dimensions
    img_h, img_w = img0.shape
    #write-up: size of Gaussian filter
    hsize = 2 * int(np.ceil(3 * sigma)) + 1

    # Gaussian kernel using outer product
    gaussian_1d = signal.windows.gaussian(hsize, sigma)
    gaussian_2d = np.outer(gaussian_1d, gaussian_1d) / np.sum(np.outer(gaussian_1d, gaussian_1d))

    # Gaussian smoothing
    img_smoothed = myImageFilter(img0, gaussian_2d, False)

    # Sobel filters x gradients
    sobel_x = np.array([[1, 0, -1], [2, 0, -2], [1, 0, -1]])
    # Sobel filters y gradients
    sobel_y = np.array([[1, 2, 1], [0, 0, 0], [-1, -2, -1]])

    # gradients (write-up imgx imgy)
    imgx = myImageFilter(img_smoothed, sobel_x, True)
    imgy = myImageFilter(img_smoothed, sobel_y, True)
    grad_magnitude = np.sqrt(imgx**2 + imgy**2)

    # normalize magnitude values -> range [0,255]
    grad_magnitude = np.clip(grad_magnitude, 0, 255)

    # Copy magnitude for NMS
    output = grad_magnitude.copy()

    # gradient directions 
    # (angles in degrees, normalized to [0,180])
    gradient_angle = (np.arctan2(imgy, imgx) * 180 / np.pi) % 180

    # write-up: Define mapping of angles to step pairs for NMS
    stepMap = [
        [(0, 1), (0, -1)], # 0 degrees
        [(-1, -1), (1, 1)], # 45
        [(1, 0), (-1, 0)], # 90
        [(1, -1), (-1, 1)], # 135
        [(0, 1), (0, -1)] # 180 (== 0)
    ]

    # Pad image -> boundary handling
    img_padded = np.pad(grad_magnitude, 1, mode="edge")

    # apply Vectorized NMS
    for x in range(1, img_h + 1):
        for y in range(1, img_w + 1):
            angle_idx = get_closest_angle_index(gradient_angle[x-1, y-1])
            (x1, y1), (x2, y2) = stepMap[angle_idx]
            if img_padded[x + x1, y + y1] > img_padded[x, y] or img_padded[x + x2, y + y2] > img_padded[x, y]:
                output[x-1, y-1] = 0

    return output
