import numpy as np
import cv2

def myHoughLines(H, nLines):
    # (NMS) w. maximum filter
    # retain only peak values
    local_maxima = (H == np.maximum.reduce([
        np.roll(H, (i, j), axis=(0, 1)) for i in (-1, 0, 1) for j in (-1, 0, 1)
    ]))
    # keep only local maxima in accumulator
    suppressed_accum = H * local_maxima  
    
    # ind indices of the top num_lines strongest peaks
    peak_indices = np.argpartition(suppressed_accum.ravel(), -nLines)[-nLines:]
    peak_indices = np.column_stack(np.unravel_index(peak_indices, H.shape))
    
    # Extract rhos & thetas directly as NumPy arrays
    rho_peaks = peak_indices[:, 0] 
    theta_peaks = peak_indices[:, 1]
    
    return np.array(rho_peaks), np.array(theta_peaks)

