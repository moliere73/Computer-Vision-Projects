
import numpy as np

def myHoughLineSegments(lineRho, lineTheta, Im):
    # dimensions
    img_h, img_w = Im.shape

    segments = []

    # precompute cos & sin values
    cosTheta = np.cos(lineTheta)
    sinTheta = np.sin(lineTheta)

    # Iterate thru each detected line
    # -> extract meaningful segments
    for rho, cos_theta, sin_theta in zip(lineRho, cosTheta, sinTheta):
        
        # base point (x0, y0) of the detected line in Cartesian 
        x0, y0 = rho * cos_theta, rho * sin_theta

        # extend lines
        x1, y1 = int(x0 + 1000 * (-sin_theta)), int(y0 + 1000 * cos_theta)
        x2, y2 = int(x0 - 1000 * (-sin_theta)), int(y0 - 1000 * cos_theta)

        # check line endpoints stay within image boundaries
        x1, y1 = np.clip([x1, y1], 0, [img_w - 1, img_h - 1])
        x2, y2 = np.clip([x2, y2], 0, [img_w - 1, img_h - 1])

        # retain segment only if it intersects with an edge in the image
        if Im[y1, x1] or Im[y2, x2]:
            segments.append((x1, y1, x2, y2))

    return segments

